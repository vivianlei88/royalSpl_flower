import { useState, useEffect } from 'react';
import { Check, Github, Database, Megaphone, Target, Link as LinkIcon, MessageSquareCode, Cloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export default function AdminSettingsMarketing() {
  const [apiKey, setApiKey] = useState(localStorage.getItem('doubao_api_key') || '');
  const [endpoint, setEndpoint] = useState(localStorage.getItem('doubao_endpoint') || 'https://api.cloudflare.com/client/v4/accounts/YOUR_ACCOUNT_ID/ai/run/@cf/doubao-seed-2-1-turbo-260628');
  const [googleTag, setGoogleTag] = useState(localStorage.getItem('google_tag_id') || '');
  const [fbPixel, setFbPixel] = useState(localStorage.getItem('fb_pixel_id') || '');
  const [isCloudflareConnected, setIsCloudflareConnected] = useState(false);

  useEffect(() => {
    setIsCloudflareConnected(!!apiKey && !!endpoint);
  }, [apiKey, endpoint]);

  const saveBotSettings = () => {
    localStorage.setItem('doubao_api_key', apiKey);
    localStorage.setItem('doubao_endpoint', endpoint);
    setIsCloudflareConnected(!!apiKey && !!endpoint);
    toast.success('Doubao 機器人設定已儲存');
  };

  const saveIntegration = (key: string, value: string, name: string) => {
    localStorage.setItem(key, value);
    toast.success(`${name} 設定已儲存`);
  };

  const staticIntegrations = [
    {
      id: 'github',
      name: 'GitHub',
      description: '您的代碼已安全儲存至 https://github.com/vivianlei88/royalSpl_flower.git',
      icon: <Github className="h-6 w-6" />,
      connected: true,
      action: '查看'
    },
    {
      id: 'supabase',
      name: 'Supabase',
      description: '資料已推送並儲存至 https://lzyihaghiqlsbtdbvkqj.supabase.co 專案。',
      icon: <Database className="h-6 w-6 text-emerald-500" />,
      connected: true,
      action: '查看'
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-2 text-primary mb-2">
          <Megaphone className="h-5 w-5" />
          <h1 className="text-2xl font-semibold">行銷整合</h1>
        </div>
        <p className="text-muted-foreground">使用這些工具讓您的行銷與營運更有效率。</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {staticIntegrations.map((item) => (
          <Card key={item.id} className="flex flex-col">
            <CardHeader>
              <div className="flex items-center gap-3">
                {item.icon}
                <CardTitle className="text-lg">{item.name}</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <CardDescription className="text-sm leading-relaxed whitespace-pre-wrap">
                {item.description}
              </CardDescription>
            </CardContent>
            <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
              <Button variant="outline" size="sm" className="rounded-full px-6" onClick={() => toast.success('這是一項系統級整合，目前運作正常')}>
                {item.action}
              </Button>
              {item.connected && (
                <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600">
                  <Check className="h-4 w-4" />
                  已連結
                </div>
              )}
            </CardFooter>
          </Card>
        ))}

        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Target className="h-6 w-6 text-blue-500" />
              <CardTitle className="text-lg">Google 代碼</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm leading-relaxed whitespace-pre-wrap">
              使用單一「Google 代碼」將網站連結到 Google Analytics (分析)、Google 廣告轉換和其他 Google 產品。
            </CardDescription>
            <div className="space-y-2">
              <Label htmlFor="google-tag">追蹤 ID (G-XXXXXXXXXX)</Label>
              <Input 
                id="google-tag" 
                value={googleTag}
                onChange={(e) => setGoogleTag(e.target.value)}
                placeholder="G-" 
              />
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" onClick={() => saveIntegration('google_tag_id', googleTag, 'Google 代碼')}>
              儲存
            </Button>
            {!!googleTag && (
              <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600">
                <Check className="h-4 w-4" />
                已連結
              </div>
            )}
          </CardFooter>
        </Card>

        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Target className="h-6 w-6 text-blue-600" />
              <CardTitle className="text-lg">Meta 像素與 CAPI</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm leading-relaxed whitespace-pre-wrap">
              追蹤轉換率，衡量 Facebook 行銷活動是否成功。包含 FB/IG 客服與自動發文連結功能。
            </CardDescription>
            <div className="space-y-2">
              <Label htmlFor="fb-pixel">Pixel ID</Label>
              <Input 
                id="fb-pixel" 
                value={fbPixel}
                onChange={(e) => setFbPixel(e.target.value)}
                placeholder="輸入您的 Pixel ID" 
              />
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" onClick={() => saveIntegration('fb_pixel_id', fbPixel, 'Meta 像素')}>
              儲存
            </Button>
            {!!fbPixel && (
              <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600">
                <Check className="h-4 w-4" />
                已連結
              </div>
            )}
          </CardFooter>
        </Card>

        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Cloud className="h-6 w-6 text-orange-500" />
              <CardTitle className="text-lg">Cloudflare</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm leading-relaxed whitespace-pre-wrap">
              配置您的 Cloudflare Workers AI 環境，做為應用程式的無伺服器後端節點。
            </CardDescription>
            <div className="space-y-2">
              <Label htmlFor="endpoint">API Endpoint</Label>
              <Input 
                id="endpoint" 
                value={endpoint} 
                onChange={(e) => setEndpoint(e.target.value)}
                placeholder="https://api.cloudflare.com/..."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="apikey">API Key / Token</Label>
              <Input 
                id="apikey" 
                type="password"
                value={apiKey} 
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="輸入您的 Cloudflare API Token"
              />
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" onClick={saveBotSettings}>
              儲存
            </Button>
            {isCloudflareConnected && (
              <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600">
                <Check className="h-4 w-4" />
                已連結
              </div>
            )}
          </CardFooter>
        </Card>

        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <MessageSquareCode className="h-6 w-6 text-indigo-500" />
              <CardTitle className="text-lg">客服機器人 (Doubao)</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm leading-relaxed whitespace-pre-wrap">
              基於 doubao-seed-2-1-turbo-260628 模型，作為網站前台與後台的智慧客服。此功能依賴於 Cloudflare 環境。
            </CardDescription>
            {isCloudflareConnected ? (
               <div className="p-4 bg-emerald-500/10 text-emerald-700 rounded-md text-sm border border-emerald-500/20">
                 Cloudflare 已連結，Doubao 模型已準備就緒，客服機器人可正常運作。
               </div>
            ) : (
               <div className="p-4 bg-destructive/10 text-destructive rounded-md text-sm border border-destructive/20">
                 請先完成左側的 Cloudflare API 設定，方可啟用 Doubao 客服機器人。
               </div>
            )}
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" disabled={!isCloudflareConnected} onClick={() => toast.success('客服機器人已套用設定並啟用')}>
              重啟機器人
            </Button>
            {isCloudflareConnected && (
              <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600">
                <Check className="h-4 w-4" />
                已啟用
              </div>
            )}
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
