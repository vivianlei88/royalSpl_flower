import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Contact from './pages/Contact';
import Login from './pages/Login';
import NotFound from './pages/NotFound';
import AdminDashboard from './pages/AdminDashboard';
import AdminProducts from './pages/AdminProducts';
import AdminOrders from './pages/AdminOrders';
import AdminContent from './pages/AdminContent';
import AdminCategories from './pages/AdminCategories';
import AdminInventory from './pages/AdminInventory';
import AdminSettingsCustomCode from './pages/AdminSettingsCustomCode';
import AdminSettingsHeadless from './pages/AdminSettingsHeadless';
import AdminSettingsMarketing from './pages/AdminSettingsMarketing';
import Cart from './pages/Cart';
import type { ReactNode } from 'react';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  /** Accessible without login. Routes without this flag require authentication. Has no effect when RouteGuard is not in use. */
  public?: boolean;
}

export const routes: RouteConfig[] = [
  {
    name: '首頁',
    path: '/',
    element: <Home />,
    public: true,
  },
  {
    name: 'Product',
    path: '/products',
    element: <Products />,
    public: true,
  },
  {
    name: 'Product Detail',
    path: '/product/:slug',
    element: <ProductDetail />,
    public: true,
  },
  {
    name: '聯絡我們',
    path: '/contact',
    element: <Contact />,
    public: true,
  },
  {
    name: '購物車',
    path: '/cart',
    element: <Cart />,
    public: true,
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    public: true,
  },
  {
    name: '頁面不存在',
    path: '/404',
    element: <NotFound />,
    public: true,
  },
  {
    name: '管理Dashboard',
    path: '/admin',
    element: <AdminDashboard />,
    public: false,
  },
  {
    name: 'Products',
    path: '/admin/products',
    element: <AdminProducts />,
    public: false,
  },
  {
    name: 'Orders',
    path: '/admin/orders',
    element: <AdminOrders />,
    public: false,
  },
  {
    name: 'SiteContent',
    path: '/admin/content',
    element: <AdminContent />,
    public: false,
  },
  {
    name: 'Categories',
    path: '/admin/categories',
    element: <AdminCategories />,
    public: false,
  },
  {
    name: 'Inventory',
    path: '/admin/inventory',
    element: <AdminInventory />,
    public: false,
  },
  {
    name: 'Settings Custom Code',
    path: '/admin/settings/custom-code',
    element: <AdminSettingsCustomCode />,
    public: false,
  },
  {
    name: 'Settings Headless',
    path: '/admin/settings/headless',
    element: <AdminSettingsHeadless />,
    public: false,
  },
  {
    name: 'Settings Marketing',
    path: '/admin/settings/marketing',
    element: <AdminSettingsMarketing />,
    public: false,
  },
];
