import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, Flower2, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/contexts/CartContext';

const navLinks = [
  { name: '首頁', path: '/' },
  { name: '產品', path: '/products' },
  { name: '聯絡我們', path: '/contact' },
];

export function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, profile, signOut } = useAuth();
  const { totalItems } = useCart();
  const navigate = useNavigate();
  const isAdmin = profile?.role === 'admin';

  async function handleLogout() {
    await signOut();
    navigate('/');
  }

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-8">
        <Link to="/" className="flex items-center gap-2">
          <Flower2 className="h-6 w-6 text-primary" />
          <span className="text-lg font-semibold tracking-tight text-foreground">Royalspl Flower</span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              {link.name}
            </Link>
          ))}
          
          <Link to="/cart" className="relative text-muted-foreground hover:text-foreground transition-colors">
            <ShoppingCart className="h-5 w-5" />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                {totalItems > 99 ? '99+' : totalItems}
              </span>
            )}
          </Link>

          {user && isAdmin ? (
            <>
              <Link to="/admin" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                後台
              </Link>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                登出
              </Button>
            </>
          ) : (
            <Link to="/login">
              <Button variant="ghost" size="sm">登入</Button>
            </Link>
          )}
        </nav>

        {/* Mobile menu */}
        <div className="flex items-center gap-4 md:hidden">
          <Link to="/cart" className="relative text-foreground hover:text-primary transition-colors">
            <ShoppingCart className="h-5 w-5" />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                {totalItems > 99 ? '99+' : totalItems}
              </span>
            )}
          </Link>
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="開啟選單">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
    <div className="flex flex-col gap-6 mt-8">
      {navLinks.map((link) => (
        <Link
          key={link.path}
          to={link.path}
          onClick={() => setIsOpen(false)}
          className="text-lg font-medium text-foreground"
        >
          {link.name}
        </Link>
      ))}
      {user && isAdmin ? (
        <>
          <Link to="/admin" onClick={() => setIsOpen(false)} className="text-lg font-medium text-foreground">
            後台
          </Link>
          <Button variant="outline" onClick={handleLogout}>
            登出
          </Button>
        </>
      ) : (
        <Link to="/login" onClick={() => setIsOpen(false)}>
          <Button className="w-full">登入</Button>
        </Link>
      )}
    </div>
  </SheetContent>
</Sheet>
</div>
      </div>
    </header>
  );
}
