import { useEffect, useState } from 'react';
import { Header } from './Header';
import { Footer } from './Footer';
import { getSiteContent } from '@/services/api';
import { ChatWidget } from '@/components/common/ChatWidget';

export function PublicLayout({ children }: { children: React.ReactNode }) {
  const [siteContent, setSiteContent] = useState<Record<string, string>>({});

  useEffect(() => {
    async function loadContent() {
      const data = await getSiteContent();
      setSiteContent(data);
    }
    loadContent();
  }, []);

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        {children}
      </main>
      <Footer siteContent={siteContent} />
      <ChatWidget position="bottom-right" title="客服機器人" />
    </div>
  );
}
