import { Mail, Phone, MapPin, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

interface FooterProps {
  siteContent: Record<string, string>;
}

export function Footer({ siteContent }: FooterProps) {
  const address = siteContent.contact_address || '花園區布魯姆街 123 號';
  const hours = siteContent.contact_hours || '週一至週六：09:00 - 19:00';
  const phone = siteContent.contact_phone || '+852 1234 5678';
  const email = siteContent.contact_email || 'hello@royalsplflower.com';
  const footerText = siteContent.footer_text || '為每一個時刻精心打造的優雅花藝。';

  return (
    <footer className="border-t border-border bg-card">
      <div className="container mx-auto px-4 py-12 md:px-8 md:py-16">
        <div className="grid gap-10 md:grid-cols-3">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Royalspl Flower</h3>
            <p className="max-w-xs text-sm text-muted-foreground">{footerText}</p>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-foreground">聯絡方式</h3>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                <span>{address}</span>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                <span>{hours}</span>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                <span>{phone}</span>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                <span>{email}</span>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-foreground">連結</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link to="/" className="hover:text-foreground transition-colors">首頁</Link>
              </li>
              <li>
                <Link to="/products" className="hover:text-foreground transition-colors">產品</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-foreground transition-colors">聯絡我們</Link>
              </li>
              <li>
                <Link to="/login" className="hover:text-foreground transition-colors">管理員登入</Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-6 text-center text-xs text-muted-foreground">
          &copy; {new Date().getFullYear()} Royalspl Flower. 版權所有。
        </div>
      </div>
    </footer>
  );
}
