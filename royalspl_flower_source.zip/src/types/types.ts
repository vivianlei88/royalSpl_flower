export type UserRole = 'user' | 'admin';

export interface Profile {
  id: string;
  email: string | null;
  phone: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  image_url: string | null;
  description: string | null;
  sort_order: number;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  sku_code: string | null;
  english_name: string | null;
  category_id: string | null;
  price: number;
  original_price: number | null;
  description: string | null;
  style_tags: string[] | null;
  scent_notes: string[] | null;
  flower_materials: string | null;
  origin: string | null;
  specification: string | null;
  images: string[];
  featured: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  category?: Category;
}

export interface Inventory {
  id: string;
  product_id: string;
  stock_quantity: number;
  created_at: string;
  updated_at: string;
  product?: Product;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface InquiryItem {
  id: string;
  inquiry_id: string;
  product_id: string;
  quantity: number;
  price: number;
  created_at: string;
  product?: Product;
}

export interface Inquiry {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  message: string | null;
  status: string;
  total_amount: number;
  created_at: string;
  items?: InquiryItem[];
}

export interface ContactSubmission {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  message: string;
  created_at: string;
}

export interface SiteContent {
  id: string;
  key: string;
  value: string;
  created_at: string;
  updated_at: string;
}
