import { supabase } from '@/db/supabase';
import type {
  Category,
  Product,
  Inquiry,
  ContactSubmission,
  SiteContent,
  Inventory,
  CartItem
} from '@/types/types';

const PRODUCTS_BUCKET = 'products';

export async function getSiteContent(): Promise<Record<string, string>> {
  const { data, error } = await supabase
    .from('site_content')
    .select('key, value')
    .order('key');

  if (error) {
    console.error('讀取網站內容失敗：', error);
    return {};
  }

  return (data || []).reduce((acc: Record<string, string>, item) => {
    acc[item.key] = item.value;
    return acc;
  }, {});
}

export async function getCategories(): Promise<Category[]> {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('sort_order', { ascending: true });

  if (error) {
    console.error('讀取分類失敗：', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function createCategory(name: string, slug: string, image_url: string | undefined = undefined, description: string | undefined = undefined): Promise<Category | null> {
  const { data, error } = await supabase
    .from('categories')
    .insert({ name, slug, image_url, description })
    .select()
    .single();

  if (error) {
    console.error('建立分類失敗：', error);
    return null;
  }
  return data;
}

export async function updateCategory(id: string, name: string, slug: string, image_url: string | undefined = undefined, description: string | undefined = undefined): Promise<boolean> {
  const { error } = await supabase
    .from('categories')
    .update({ name, slug, image_url, description })
    .eq('id', id);

  if (error) {
    console.error('更新分類失敗：', error);
    return false;
  }
  return true;
}

export async function deleteCategory(id: string): Promise<boolean> {
  const { error } = await supabase.from('categories').delete().eq('id', id);
  if (error) {
    console.error('刪除分類失敗：', error);
    return false;
  }
  return true;
}

export async function getInventory(): Promise<Inventory[]> {
  const { data, error } = await supabase
    .from('inventory')
    .select('*, product:products(name, sku_code)')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('讀取庫存失敗：', error);
    return [];
  }
  return Array.isArray(data) ? data : [];
}

export async function updateInventory(product_id: string, stock_quantity: number): Promise<boolean> {
  const { error } = await supabase
    .from('inventory')
    .update({ stock_quantity, updated_at: new Date().toISOString() })
    .eq('product_id', product_id);

  if (error) {
    console.error('更新庫存失敗：', error);
    return false;
  }
  return true;
}

export async function getProducts(options?: {
  categorySlug?: string;
  featured?: boolean;
}): Promise<Product[]> {
  let query = supabase
    .from('products')
    .select('*, category:categories(*)')
    .eq('is_active', true)
    .order('created_at', { ascending: false });

  if (options?.featured) {
    query = query.eq('featured', true);
  }

  if (options?.categorySlug) {
    const { data: category } = await supabase
      .from('categories')
      .select('id')
      .eq('slug', options.categorySlug)
      .maybeSingle();

    if (category?.id) {
      query = query.eq('category_id', category.id);
    }
  }

  const { data, error } = await query;

  if (error) {
    console.error('讀取產品失敗：', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .select('*, category:categories(*)')
    .eq('slug', slug)
    .eq('is_active', true)
    .maybeSingle();

  if (error) {
    console.error('讀取產品詳情失敗：', error);
    return null;
  }

  return data || null;
}

export async function getAllProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*, category:categories(*)')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('讀取所有產品失敗：', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function createProduct(
  product: Omit<Product, 'id' | 'created_at' | 'updated_at' | 'category'>
): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .insert({
      name: product.name,
      slug: product.slug,
      sku_code: product.sku_code,
      english_name: product.english_name,
      category_id: product.category_id,
      price: product.price,
      original_price: product.original_price,
      description: product.description,
      style_tags: product.style_tags,
      scent_notes: product.scent_notes,
      flower_materials: product.flower_materials,
      origin: product.origin,
      specification: product.specification,
      images: product.images,
      featured: product.featured,
      is_active: product.is_active,
    })
    .select()
    .single();

  if (error) {
    console.error('建立產品失敗：', error);
    return null;
  }

  // Create initial inventory
  await supabase.from('inventory').insert({
    product_id: data.id,
    stock_quantity: 0
  });

  return data;
}

export async function updateProduct(
  id: string,
  product: Partial<Omit<Product, 'id' | 'created_at' | 'updated_at' | 'category'>>
): Promise<Product | null> {
  const { data, error } = await supabase
    .from('products')
    .update({
      ...product,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('更新產品失敗：', error);
    return null;
  }

  return data;
}

export async function deleteProduct(id: string): Promise<boolean> {
  const { error } = await supabase.from('products').delete().eq('id', id);

  if (error) {
    console.error('刪除產品失敗：', error);
    return false;
  }

  return true;
}

export async function createInquiry(
  inquiry: Omit<Inquiry, 'id' | 'status' | 'created_at' | 'items'>,
  cartItems: CartItem[]
): Promise<Inquiry | null> {
  const { data, error } = await supabase
    .from('inquiries')
    .insert({
      name: inquiry.name,
      phone: inquiry.phone,
      email: inquiry.email,
      message: inquiry.message,
      total_amount: inquiry.total_amount,
    })
    .select()
    .single();

  if (error) {
    console.error('建立詢價失敗：', error);
    return null;
  }

  if (cartItems.length > 0) {
    const items = cartItems.map(item => ({
      inquiry_id: data.id,
      product_id: item.product.id,
      quantity: item.quantity,
      price: item.product.price
    }));

    const { error: itemsError } = await supabase.from('inquiry_items').insert(items);
    if (itemsError) {
      console.error('建立詢價項目失敗：', itemsError);
    }
  }

  return data;
}

export async function getInquiries(): Promise<Inquiry[]> {
  const { data, error } = await supabase
    .from('inquiries')
    .select('*, items:inquiry_items(*, product:products(name, sku_code))')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('讀取詢價失敗：', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function updateInquiryStatus(
  id: string,
  status: string
): Promise<boolean> {
  const { error } = await supabase
    .from('inquiries')
    .update({ status })
    .eq('id', id);

  if (error) {
    console.error('更新詢價狀態失敗：', error);
    return false;
  }

  return true;
}

export async function createContactSubmission(
  submission: Omit<ContactSubmission, 'id' | 'created_at'>
): Promise<ContactSubmission | null> {
  const { data, error } = await supabase
    .from('contact_submissions')
    .insert({
      name: submission.name,
      phone: submission.phone,
      email: submission.email,
      message: submission.message,
    })
    .select()
    .single();

  if (error) {
    console.error('建立聯絡訊息失敗：', error);
    return null;
  }

  return data;
}

export async function getContactSubmissions(): Promise<ContactSubmission[]> {
  const { data, error } = await supabase
    .from('contact_submissions')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('讀取聯絡訊息失敗：', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
}

export async function updateSiteContent(
  key: string,
  value: string
): Promise<boolean> {
  const { error } = await supabase
    .from('site_content')
    .update({ value, updated_at: new Date().toISOString() })
    .eq('key', key);

  if (error) {
    console.error('更新網站內容失敗：', error);
    return false;
  }

  return true;
}

export async function uploadProductImage(
  file: File,
  filename: string
): Promise<string | null> {
  const { data, error } = await supabase.storage
    .from(PRODUCTS_BUCKET)
    .upload(filename, file, { contentType: file.type });

  if (error || !data?.path) {
    console.error('上傳圖片失敗：', error);
    return null;
  }

  const { data: urlData } = supabase.storage
    .from(PRODUCTS_BUCKET)
    .getPublicUrl(data.path);

  return urlData.publicUrl;
}

export async function deleteProductImage(path: string): Promise<boolean> {
  const { error } = await supabase.storage.from(PRODUCTS_BUCKET).remove([path]);

  if (error) {
    console.error('刪除圖片失敗：', error);
    return false;
  }

  return true;
}
