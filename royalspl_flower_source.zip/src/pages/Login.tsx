import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Flower2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import PageMeta from '@/components/common/PageMeta';
import { toast } from 'sonner';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const { signInWithUsername } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string })?.from || '/admin';

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!username.trim() || !password.trim()) {
      toast.error('請輸入用戶名和密碼。');
      return;
    }

    if (!agreed) {
      toast.error('請同意用戶協議及隱私政策。');
      return;
    }

    setLoading(true);
    const { error } = await signInWithUsername(username.trim(), password.trim());
    setLoading(false);

    if (error) {
      toast.error('用戶名或密碼錯誤。');
      return;
    }

    toast.success('登入成功。');
    navigate(from);
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4">
      <PageMeta title="登入 | Royalspl Flower" description="Royalspl Flower 管理系統登入。" />
      <Link to="/" className="mb-8 flex items-center gap-2">
        <Flower2 className="h-6 w-6 text-primary" />
        <span className="text-lg font-semibold text-foreground">Royalspl Flower</span>
      </Link>
      <Card className="w-full max-w-[calc(100%-2rem)] md:max-w-sm">
        <CardHeader className="space-y-1">
          <CardTitle className="text-xl">管理員登入</CardTitle>
          <CardDescription>登入以管理您的花店</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">用戶名</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="輸入用戶名"
                autoComplete="username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">密碼</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="輸入密碼"
                autoComplete="current-password"
              />
            </div>
            <div className="flex items-start space-x-2">
              <Checkbox
                id="agree"
                checked={agreed}
                onCheckedChange={(checked) => setAgreed(checked === true)}
              />
              <Label htmlFor="agree" className="text-sm font-normal leading-tight">
                我已閱讀並同意
                <Link to="/" className="text-primary hover:underline">用戶協議</Link>
                及
                <Link to="/" className="text-primary hover:underline">隱私政策</Link>
                。
              </Label>
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? '登入中...' : '登入'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
