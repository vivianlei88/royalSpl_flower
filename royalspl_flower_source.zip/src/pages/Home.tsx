import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { getSiteContent, getProducts } from '@/services/api';
import type { Product } from '@/types/types';
import PageMeta from '@/components/common/PageMeta';

export default function Home() {
  const [content, setContent] = useState<Record<string, string>>({});
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      const [siteContent, products] = await Promise.all([
        getSiteContent(),
        getProducts({ featured: true }),
      ]);
      setContent(siteContent);
      setFeaturedProducts(products);
      setLoading(false);
    }
    loadData();
  }, []);

  const heroTitle = content.hero_title || 'Royalspl Flower';
  const heroSubtitle = content.hero_subtitle || '為每一個時刻精心打造的優雅花藝';
  const heroImage = content.hero_image || featuredProducts[0]?.images?.[0];
  const aboutTitle = content.about_title || '關於 Royalspl Flower';
  const aboutText = content.about_text || '我們是一家本地花藝工作室，致力於創作細膩而優雅的花藝作品。';
  const contactHours = content.contact_hours || '週一至週六：09:00 - 19:00';
  const contactAddress = content.contact_address || '花園區布魯姆街 123 號';
  const contactPhone = content.contact_phone || '+852 1234 5678';

  return (
    <div className="flex flex-col">
      <PageMeta title="Royalspl Flower | 優雅花藝" description="Royalspl Flower 提供適合婚禮、活動與日常生活的優雅花藝設計。" />

      {/* Hero Section */}
      <section className="relative w-full">
        <div className="container mx-auto px-4 py-20 md:py-32 md:px-8">
          <div className="grid items-center gap-12 md:grid-cols-2 lg:gap-16">
            <div className="space-y-8 opacity-0 intersect:opacity-100 transition duration-700">
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-primary">
                本地花藝工作室
              </p>
              <h1 className="text-4xl font-semibold leading-[1.1] tracking-tight text-foreground md:text-6xl lg:text-7xl">
                {heroTitle}
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-md leading-relaxed">
                {heroSubtitle}
              </p>
              <div className="flex flex-wrap gap-4 pt-2">
                <Button size="lg" asChild>
                  <Link to="/products">
                    瀏覽花藝
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link to="/contact">聯絡我們</Link>
                </Button>
              </div>
            </div>

            {heroImage && (
              <div className="relative aspect-[4/5] overflow-hidden rounded-lg opacity-0 intersect:opacity-100 transition duration-700 delay-100">
                <img
                  src={heroImage}
                  alt="Royalspl Flower 主視覺花藝"
                  className="h-full w-full object-cover"
                />
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 精選產品 */}
      <section className="container mx-auto px-4 py-16 md:py-24 md:px-8">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-foreground md:text-3xl">精選花藝</h2>
            <p className="mt-2 text-muted-foreground">為每個場合精心挑選的花藝設計。</p>
          </div>
          <Button variant="ghost" asChild className="hidden md:flex items-center">
            <Link to="/products">
              查看全部
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>

        {loading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="h-full overflow-hidden border border-border bg-card">
                <div className="aspect-[4/3] bg-muted animate-pulse" />
                <CardContent className="p-5 space-y-3">
                  <div className="h-5 w-2/3 bg-muted animate-pulse rounded" />
                  <div className="h-4 w-1/3 bg-muted animate-pulse rounded" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <>
            {featuredProducts.length > 0 ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {featuredProducts.map((product) => (
                  <Link key={product.id} to={`/product/${product.slug}`}>
                    <Card className="h-full overflow-hidden border border-border bg-card transition-colors hover:border-primary/50">
                      <div className="aspect-[4/3] overflow-hidden bg-muted">
                        <img
                          src={product.images?.[0]}
                          alt={product.name}
                          className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
                        />
                      </div>
                      <CardContent className="p-5">
                        <h3 className="text-base font-semibold text-foreground">{product.name}</h3>
                        <p className="mt-1 text-sm text-muted-foreground">{product.category?.name}</p>
                        <p className="mt-2 text-base font-medium text-primary">HK${Number(product.price).toFixed(2)}</p>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="rounded-lg border border-border bg-card p-8 text-center text-muted-foreground">
                暫無精選產品。
              </div>
            )}

            <div className="mt-8 md:hidden">
              <Button variant="outline" asChild className="w-full">
                <Link to="/products">
                  查看所有產品
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </>
        )}
      </section>

      {/* About Section */}
      <section className="bg-card">
        <div className="container mx-auto px-4 py-20 md:py-28 md:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="text-sm font-medium uppercase tracking-[0.2em] text-primary mb-6">我們的故事</p>
            <h2 className="text-3xl font-semibold text-foreground md:text-4xl">{aboutTitle}</h2>
            <p className="mt-8 text-lg leading-relaxed text-muted-foreground">
              {aboutText}
            </p>
          </div>
        </div>
      </section>

      {/* Contact Info Section */}
      <section className="container mx-auto px-4 py-16 md:py-24 md:px-8">
        <div className="grid gap-8 md:grid-cols-3">
          <Card className="border border-border bg-card p-6">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-foreground">地址</h3>
            <p className="mt-2 text-muted-foreground">{contactAddress}</p>
          </Card>
          <Card className="border border-border bg-card p-6">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-foreground">營業時間</h3>
            <p className="mt-2 text-muted-foreground">{contactHours}</p>
          </Card>
          <Card className="border border-border bg-card p-6">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-foreground">電話</h3>
            <p className="mt-2 text-muted-foreground">{contactPhone}</p>
          </Card>
        </div>
      </section>
    </div>
  );
}
