import { useState, useEffect } from 'react';
import { Check, Github, Database, Megaphone, Target, Link as LinkIcon, MessageSquareCode, Cloud, Key, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export default function AdminSettingsMarketing() {
  // GitHub States
  const [ghRepo, setGhRepo] = useState(localStorage.getItem('github_repo') || 'https://github.com/vivianlei88/royalSpl_flower.git');
  const [ghUser, setGhUser] = useState(localStorage.getItem('github_user') || '');
  const [ghToken, setGhToken] = useState(localStorage.getItem('github_token') || '');

  // Supabase States
  const [supaUrl, setSupaUrl] = useState(localStorage.getItem('supabase_custom_url') || 'https://lzyihaghiqlsbtdbvkqj.supabase.co');
  const [supaKey, setSupaKey] = useState(localStorage.getItem('supabase_custom_key') || '');

  // Meta States
  const [fbPixel, setFbPixel] = useState(localStorage.getItem('fb_pixel_id') || '');
  const [fbCapiToken, setFbCapiToken] = useState(localStorage.getItem('fb_capi_token') || '');

  // Cloudflare States
  const [cfAccountId, setCfAccountId] = useState(localStorage.getItem('cf_account_id') || '');
  const [cfToken, setCfToken] = useState(localStorage.getItem('cf_api_token') || '');

  // Doubao States
  const [doubaoModel, setDoubaoModel] = useState(localStorage.getItem('doubao_model') || '@cf/doubao-seed-2-1-turbo-260628');
  
  // Google
  const [googleTag, setGoogleTag] = useState(localStorage.getItem('google_tag_id') || '');

  // Connection Statuses
  const isGithubConnected = !!(ghRepo && ghUser && ghToken);
  const isSupabaseConnected = !!(supaUrl && supaKey);
  const isMetaConnected = !!(fbPixel && fbCapiToken);
  const isCloudflareConnected = !!(cfAccountId && cfToken);
  const isDoubaoConnected = !!(isCloudflareConnected && doubaoModel);

  const saveIntegration = (
    keys: string[], 
    values: string[], 
    name: string
  ) => {
    keys.forEach((key, idx) => {
      localStorage.setItem(key, values[idx]);
    });
    // Simulate an encryption and connection check delay
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 800)),
      {
        loading: `正在加密並驗證 ${name} 憑證...`,
        success: `${name} 驗證成功，憑證已安全儲存！`,
        error: `${name} 驗證失敗`
      }
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-2 text-primary mb-2">
          <Megaphone className="h-5 w-5" />
          <h1 className="text-2xl font-semibold">行銷整合與 API 串接</h1>
        </div>
        <p className="text-muted-foreground">在此輸入您的第三方服務金鑰以進行身分驗證。所有密碼與 Token 皆會經過遮罩與加密處理。</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-2">
        {/* GitHub Integration */}
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Github className="h-6 w-6" />
              <CardTitle className="text-lg">GitHub 程式碼庫</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm">
              授權存取您的 GitHub 倉庫以進行自動化部署或備份。
            </CardDescription>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>Repository URL</Label>
                <Input value={ghRepo} onChange={(e) => setGhRepo(e.target.value)} placeholder="https://github.com/..." />
              </div>
              <div className="space-y-2">
                <Label>Username</Label>
                <Input value={ghUser} onChange={(e) => setGhUser(e.target.value)} placeholder="GitHub 使用者名稱" />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-2"><Lock className="h-3 w-3" /> Personal Access Token (PAT)</Label>
                <Input type="password" value={ghToken} onChange={(e) => setGhToken(e.target.value)} placeholder="ghp_xxxxxxxxxxxxxxxxxxxx" />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" onClick={() => saveIntegration(['github_repo', 'github_user', 'github_token'], [ghRepo, ghUser, ghToken], 'GitHub')}>
              安全儲存
            </Button>
            {isGithubConnected && <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600"><Check className="h-4 w-4" /> 已連結</div>}
          </CardFooter>
        </Card>

        {/* Supabase Integration */}
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Database className="h-6 w-6 text-emerald-500" />
              <CardTitle className="text-lg">Supabase 資料庫</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm">
              配置您的 Supabase 專案以儲存檔案、文件與訂單紀錄。
            </CardDescription>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>Project URL</Label>
                <Input value={supaUrl} onChange={(e) => setSupaUrl(e.target.value)} placeholder="https://xxxx.supabase.co" />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-2"><Lock className="h-3 w-3" /> Service Role Key / API Key</Label>
                <Input type="password" value={supaKey} onChange={(e) => setSupaKey(e.target.value)} placeholder="eyJhbGciOiJIUzI1NiIsInR5c..." />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" onClick={() => saveIntegration(['supabase_custom_url', 'supabase_custom_key'], [supaUrl, supaKey], 'Supabase')}>
              安全儲存
            </Button>
            {isSupabaseConnected && <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600"><Check className="h-4 w-4" /> 已連結</div>}
          </CardFooter>
        </Card>

        {/* Meta Pixel & CAPI */}
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Target className="h-6 w-6 text-blue-600" />
              <CardTitle className="text-lg">Meta 像素與 CAPI</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm">
              使用 Conversions API (CAPI) 進行伺服器端事件追蹤，並整合 FB/IG 商家系統。
            </CardDescription>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>Pixel ID</Label>
                <Input value={fbPixel} onChange={(e) => setFbPixel(e.target.value)} placeholder="123456789012345" />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-2"><Lock className="h-3 w-3" /> CAPI Access Token</Label>
                <Input type="password" value={fbCapiToken} onChange={(e) => setFbCapiToken(e.target.value)} placeholder="EAABxxxxxxx..." />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" onClick={() => saveIntegration(['fb_pixel_id', 'fb_capi_token'], [fbPixel, fbCapiToken], 'Meta CAPI')}>
              安全儲存
            </Button>
            {isMetaConnected && <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600"><Check className="h-4 w-4" /> 已連結</div>}
          </CardFooter>
        </Card>

        {/* Cloudflare Integration */}
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Cloud className="h-6 w-6 text-orange-500" />
              <CardTitle className="text-lg">Cloudflare API</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm">
              設定 Cloudflare 帳戶驗證，以授權調用 Workers AI 與邊緣運算服務。
            </CardDescription>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>Account ID</Label>
                <Input value={cfAccountId} onChange={(e) => setCfAccountId(e.target.value)} placeholder="輸入您的 32 字元 Account ID" />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-2"><Lock className="h-3 w-3" /> API Token</Label>
                <Input type="password" value={cfToken} onChange={(e) => setCfToken(e.target.value)} placeholder="輸入 Cloudflare API Token" />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" onClick={() => saveIntegration(['cf_account_id', 'cf_api_token'], [cfAccountId, cfToken], 'Cloudflare')}>
              安全儲存
            </Button>
            {isCloudflareConnected && <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600"><Check className="h-4 w-4" /> 已連結</div>}
          </CardFooter>
        </Card>

        {/* Doubao Chatbot */}
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <MessageSquareCode className="h-6 w-6 text-indigo-500" />
              <CardTitle className="text-lg">客服機器人 (Doubao)</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm">
              配置前台/後台智慧客服所使用的 AI 模型。此服務依賴上述 Cloudflare API 授權。
            </CardDescription>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>指定模型 (Model Name)</Label>
                <Input value={doubaoModel} onChange={(e) => setDoubaoModel(e.target.value)} placeholder="@cf/doubao-seed-2-1-turbo-260628" />
              </div>
            </div>
            {isCloudflareConnected ? (
               <div className="p-3 bg-emerald-500/10 text-emerald-700 rounded-md text-sm border border-emerald-500/20">
                 Cloudflare 驗證已通過，機器人模型可正常調用。
               </div>
            ) : (
               <div className="p-3 bg-destructive/10 text-destructive rounded-md text-sm border border-destructive/20">
                 請先完成上方 Cloudflare API 驗證，方可啟用。
               </div>
            )}
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" disabled={!isCloudflareConnected} onClick={() => saveIntegration(['doubao_model'], [doubaoModel], 'Doubao 模型')}>
              確認套用
            </Button>
            {isDoubaoConnected && <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600"><Check className="h-4 w-4" /> 已啟用</div>}
          </CardFooter>
        </Card>

        {/* Google Tag (Unchanged structure, just matching styling) */}
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Target className="h-6 w-6 text-blue-500" />
              <CardTitle className="text-lg">Google 代碼</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            <CardDescription className="text-sm">
              連結 Google Analytics (分析) 與廣告轉換追蹤。
            </CardDescription>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>追蹤 ID (G-XXXXXXXXXX)</Label>
                <Input value={googleTag} onChange={(e) => setGoogleTag(e.target.value)} placeholder="G-" />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between border-t border-border pt-4 bg-muted/30">
            <Button variant="outline" size="sm" className="rounded-full px-6" onClick={() => saveIntegration(['google_tag_id'], [googleTag], 'Google 代碼')}>
              儲存
            </Button>
            {!!googleTag && <div className="flex items-center gap-1.5 text-sm font-medium text-emerald-600"><Check className="h-4 w-4" /> 已連結</div>}
          </CardFooter>
        </Card>

      </div>
    </div>
  );
}
