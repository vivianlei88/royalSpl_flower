import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useCart } from '@/contexts/CartContext';
import { createInquiry } from '@/services/api';
import PageMeta from '@/components/common/PageMeta';
import { toast } from 'sonner';

export default function Cart() {
  const { items, updateQuantity, removeFromCart, totalAmount, clearCart } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', phone: '', email: '', message: '' });
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (items.length === 0) {
      toast.error('購物車是空的');
      return;
    }

    if (!form.name.trim() || !form.phone.trim()) {
      toast.error('請填寫您的姓名和電話');
      return;
    }

    setSubmitting(true);
    const success = await createInquiry({
      name: form.name.trim(),
      phone: form.phone.trim(),
      email: form.email.trim() || null,
      message: form.message.trim() || null,
      total_amount: totalAmount,
    }, items);
    setSubmitting(false);

    if (success) {
      toast.success('訂單確認成功，我們會盡快與您聯絡。');
      clearCart();
      navigate('/');
    } else {
      toast.error('訂單提交失敗，請重試。');
    }
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center md:px-8">
        <PageMeta title="購物車 | Royalspl Flower" description="您的購物車" />
        <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-muted">
          <ShoppingBag className="h-10 w-10 text-muted-foreground" />
        </div>
        <h1 className="text-2xl font-semibold text-foreground">您的購物車是空的</h1>
        <p className="mt-2 text-muted-foreground">瀏覽我們的產品系列，尋找適合您的花藝設計。</p>
        <Button className="mt-8" asChild>
          <Link to="/products">瀏覽產品</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 md:py-20 md:px-8">
      <PageMeta title="購物車 | Royalspl Flower" description="您的購物車" />
      
      <h1 className="mb-10 text-3xl font-semibold text-foreground md:text-4xl">購物車</h1>

      <div className="grid gap-10 lg:grid-cols-12">
        <div className="lg:col-span-7 xl:col-span-8">
          <div className="space-y-6">
            {items.map((item) => (
              <div key={item.product.id} className="flex gap-4 rounded-lg border border-border bg-card p-4 sm:items-center">
                <div className="h-24 w-24 shrink-0 overflow-hidden rounded-md bg-muted sm:h-32 sm:w-32">
                  <img
                    src={item.product.images?.[0]}
                    alt={item.product.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="flex flex-1 flex-col justify-between">
                  <div className="flex justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-foreground">
                        <Link to={`/product/${item.product.slug}`} className="hover:underline">
                          {item.product.name}
                        </Link>
                      </h3>
                      {item.product.sku_code && (
                        <p className="text-sm text-muted-foreground">{item.product.sku_code}</p>
                      )}
                    </div>
                    <p className="font-medium text-primary whitespace-nowrap">
                      HK${Number(item.product.price).toFixed(2)}
                    </p>
                  </div>
                  
                  <div className="mt-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-8 text-center text-sm">{item.quantity}</span>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="text-muted-foreground hover:text-destructive"
                      onClick={() => removeFromCart(item.product.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 xl:col-span-4">
          <div className="sticky top-20 rounded-lg border border-border bg-card p-6">
            <h2 className="text-xl font-semibold text-foreground">訂單摘要</h2>
            
            <div className="mt-6 space-y-4 border-b border-border pb-6">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">小計 ({items.length} 件商品)</span>
                <span className="font-medium text-foreground">HK${totalAmount.toFixed(2)}</span>
              </div>
            </div>
            
            <div className="flex justify-between py-6">
              <span className="text-base font-semibold text-foreground">總計</span>
              <span className="text-xl font-bold text-primary">HK${totalAmount.toFixed(2)}</span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 pt-4 border-t border-border">
              <h3 className="font-medium">填寫聯絡資料提交詢價</h3>
              
              <div className="space-y-2">
                <Label htmlFor="name">姓名 <span className="text-destructive">*</span></Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="您的姓名"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">電話 <span className="text-destructive">*</span></Label>
                <Input
                  id="phone"
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="您的聯絡電話"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">電子郵件</Label>
                <Input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="您的電子郵件（選填）"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="message">留言</Label>
                <Textarea
                  id="message"
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="請輸入您的需求或問題（選填）"
                  rows={3}
                />
              </div>
              
              <Button type="submit" className="mt-4 w-full" size="lg" disabled={submitting}>
                {submitting ? '提交中...' : '提交詢價清單'}
                {!submitting && <ArrowRight className="ml-2 h-4 w-4" />}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}