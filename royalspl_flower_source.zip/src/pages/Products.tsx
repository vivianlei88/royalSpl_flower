import { useEffect, useState, useCallback } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { ShoppingCart, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { getCategories, getProducts } from '@/services/api';
import type { Product, Category } from '@/types/types';
import PageMeta from '@/components/common/PageMeta';
import { useCart } from '@/contexts/CartContext';

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const selectedCategory = searchParams.get('category') || 'all';
  const { addToCart } = useCart();
  const navigate = useNavigate();

  const loadData = useCallback(async () => {
    const [productsData, categoriesData] = await Promise.all([
      getProducts({ categorySlug: selectedCategory === 'all' ? undefined : selectedCategory }),
      getCategories(),
    ]);
    setProducts(productsData);
    setCategories(categoriesData);
    setLoading(false);
  }, [selectedCategory]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  function handleCategoryChange(category: string) {
    if (category === 'all') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', category);
    }
    setSearchParams(searchParams);
  }

  function handleBuyNow(product: Product) {
    addToCart(product, 1);
    navigate('/cart');
  }

  return (
    <div className="container mx-auto px-4 py-12 md:py-20 md:px-8">
      <PageMeta
        title="產品 | Royalspl Flower"
        description="瀏覽我們優雅的花藝與植物系列。"
      />

      <div className="mb-10 text-center">
        <h1 className="text-3xl font-semibold text-foreground md:text-4xl">產品系列</h1>
        <p className="mt-4 text-muted-foreground">發現適合各種場合的花藝設計。</p>
      </div>

      <div className="mb-8 flex flex-wrap justify-center gap-2">
        <Button
          variant={selectedCategory === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => handleCategoryChange('all')}
        >
          全部
        </Button>
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.slug ? 'default' : 'outline'}
            size="sm"
            onClick={() => handleCategoryChange(category.slug)}
          >
            {category.name}
          </Button>
        ))}
      </div>

      {loading ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="h-full overflow-hidden border border-border bg-card">
              <div className="aspect-[4/3] bg-muted animate-pulse" />
              <CardContent className="p-5 space-y-3">
                <div className="h-5 w-2/3 bg-muted animate-pulse rounded" />
                <div className="h-4 w-1/3 bg-muted animate-pulse rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : products.length > 0 ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => (
            <div key={product.id}>
              <Card className="h-full flex flex-col overflow-hidden border border-border bg-card transition-colors hover:border-primary/50">
                <Link to={`/product/${product.slug}`} className="block relative aspect-[4/3] overflow-hidden bg-muted">
                  <img
                    src={product.images?.[0]}
                    alt={product.name}
                    className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                </Link>
                <CardContent className="p-5 flex-1 min-w-0">
                  <Link to={`/product/${product.slug}`}>
                    <h3 className="text-base font-semibold text-foreground truncate">{product.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground truncate">{product.category?.name}</p>
                    <p className="mt-2 text-base font-medium text-primary">HK${Number(product.price).toFixed(2)}</p>
                  </Link>
                </CardContent>
                <CardFooter className="p-5 pt-0 mt-auto shrink-0 flex gap-2">
                  <Button className="flex-1" variant="outline" size="sm" onClick={() => addToCart(product, 1)}>
                    <ShoppingCart className="h-4 w-4" />
                  </Button>
                  <Button className="flex-[3]" size="sm" onClick={() => handleBuyNow(product)}>
                    立即購買
                  </Button>
                </CardFooter>
              </Card>
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-card p-8 text-center text-muted-foreground">
          此分類暫無產品。
        </div>
      )}
    </div>
  );
}
