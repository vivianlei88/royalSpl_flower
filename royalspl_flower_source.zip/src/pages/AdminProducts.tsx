import { useEffect, useState } from 'react';
import Papa from 'papaparse';
import { Pencil, Trash2, Plus, X, Upload, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  getAllProducts,
  getCategories,
  createProduct,
  updateProduct,
  deleteProduct,
  uploadProductImage,
} from '@/services/api';
import type { Product, Category } from '@/types/types';
import { toast } from 'sonner';

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchKeyword, setSearchKeyword] = useState<string>('');
  const [form, setForm] = useState({
    name: '',
    slug: '',
    sku_code: '',
    english_name: '',
    category_id: '',
    price: '',
    original_price: '',
    description: '',
    style_tags: '',
    scent_notes: '',
    flower_materials: '',
    origin: '',
    specification: '',
    images: [] as string[],
    featured: false,
    is_active: true,
  });
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const [productsData, categoriesData] = await Promise.all([
      getAllProducts(),
      getCategories(),
    ]);
    setProducts(productsData);
    setCategories(categoriesData);
    setLoading(false);
  }

  function resetForm() {
    setForm({
      name: '',
      slug: '',
      sku_code: '',
      english_name: '',
      category_id: '',
      price: '',
      original_price: '',
      description: '',
      style_tags: '',
      scent_notes: '',
      flower_materials: '',
      origin: '',
      specification: '',
      images: [],
      featured: false,
      is_active: true,
    });
    setEditingId(null);
  }

  function openEdit(product: Product) {
    setEditingId(product.id);
    setForm({
      name: product.name,
      slug: product.slug,
      sku_code: product.sku_code || '',
      english_name: product.english_name || '',
      category_id: product.category_id || '',
      price: String(product.price),
      original_price: product.original_price ? String(product.original_price) : '',
      description: product.description || '',
      style_tags: product.style_tags ? product.style_tags.join(', ') : '',
      scent_notes: product.scent_notes ? product.scent_notes.join(', ') : '',
      flower_materials: product.flower_materials || '',
      origin: product.origin || '',
      specification: product.specification || '',
      images: product.images || [],
      featured: product.featured,
      is_active: product.is_active,
    });
    setDialogOpen(true);
  }

  function openCreate() {
    resetForm();
    setDialogOpen(true);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();

    if (!form.name.trim() || !form.price.trim()) {
      toast.error('請填寫名稱和價格。');
      return;
    }

    const price = parseFloat(form.price);
    const originalPrice = form.original_price ? parseFloat(form.original_price) : null;

    if (isNaN(price) || price < 0) {
      toast.error('請輸入有效的價格。');
      return;
    }

    const payload = {
      name: form.name.trim(),
      slug: form.slug ? form.slug.trim() : (form.sku_code ? form.sku_code.trim().toLowerCase() : `product-${Date.now()}`),
      sku_code: form.sku_code ? form.sku_code.trim() : null,
      english_name: form.english_name ? form.english_name.trim() : null,
      category_id: form.category_id || null,
      price,
      original_price: originalPrice,
      description: form.description ? form.description.trim() : null,
      style_tags: form.style_tags ? form.style_tags.split(',').map(s => s.trim()).filter(Boolean) : null,
      scent_notes: form.scent_notes ? form.scent_notes.split(',').map(s => s.trim()).filter(Boolean) : null,
      flower_materials: form.flower_materials ? form.flower_materials.trim() : null,
      origin: form.origin ? form.origin.trim() : null,
      specification: form.specification ? form.specification.trim() : null,
      images: form.images,
      featured: form.featured,
      is_active: form.is_active,
    };

    let result;
    if (editingId) {
      result = await updateProduct(editingId, payload);
    } else {
      result = await createProduct(payload as Parameters<typeof createProduct>[0]);
    }

    if (result) {
      toast.success(editingId ? '產品已更新。' : '產品已建立。');
      setDialogOpen(false);
      resetForm();
      loadData();
    } else {
      toast.error('產品儲存失敗。');
    }
  }

  async function handleDelete(id: string) {
    const success = await deleteProduct(id);
    if (success) {
      toast.success('產品已刪除。');
      setDeletingId(null);
      loadData();
    } else {
      toast.error('刪除產品失敗。');
    }
  }

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 1024) {
      toast.error('圖片必須小於 1MB。');
      return;
    }

    setUploading(true);
    const filename = `${Date.now()}-${file.name}`;
    const url = await uploadProductImage(file, filename);
    setUploading(false);

    if (url) {
      setForm((prev) => ({ ...prev, images: [...prev.images, url] }));
    } else {
      toast.error('圖片上傳失敗。');
    }
  }

  async function handleCsvUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const rows = results.data as Record<string, string>[];
          let successCount = 0;
          
          for (const row of rows) {
            // flower.csv mapping
            const payload = {
              name: row['product_name'] || '',
              slug: (row['sku_code'] || `product-${Date.now()}`).toLowerCase(),
              sku_code: row['sku_code'] || null,
              english_name: row['english_name'] || null,
              category_id: null, // Would need name-to-id mapping for real category
              price: parseFloat(row['price'] || '0'),
              original_price: row['Original price'] ? parseFloat(row['Original price']) : null,
              description: row['description'] || null,
              style_tags: [
                row['Product Classification'],
                row['Product Classification_1'],
                row['Product Classification_2']
              ].filter(Boolean) as string[],
              scent_notes: [],
              flower_materials: row['additionalInfoTitle'] === '花材' ? row['additionalInfoDescription1'] : null,
              origin: null,
              specification: row['additionalInfoDescription1'] || null, // Best effort mapping
              images: row['productImageUrl'] ? row['productImageUrl'].split(';') : [],
              featured: false,
              is_active: true,
            };

            if (payload.name && !isNaN(payload.price)) {
              await createProduct(payload as any);
              successCount++;
            }
          }
          
          toast.success(`成功匯入 ${successCount} 個產品`);
          loadData();
        } catch (err) {
          console.error(err);
          toast.error('匯入 CSV 失敗');
        } finally {
          setUploading(false);
          if (e.target) e.target.value = ''; // reset input
        }
      },
      error: () => {
        toast.error('解析 CSV 失敗');
        setUploading(false);
      }
    });
  }

  function handleCsvDownload() {
    if (products.length === 0) return;
    
    // Create flat structure for export based on flower.csv format
    const exportData = products.map(p => ({
      sku_code: p.sku_code || '',
      fieldType: 'Product',
      product_name: p.name,
      description: p.description || '',
      productImageUrl: p.images ? p.images.join(';') : '',
      category: p.category?.name || '',
      price: p.price,
      'Original price': p.original_price || '',
      english_name: p.english_name || '',
      'Product Classification': p.style_tags?.[0] || '',
      'Product Classification_1': p.style_tags?.[1] || '',
      'Product Classification_2': p.style_tags?.[2] || '',
      'Product Classification_3': '',
      'Product Classification_4': '',
      additionalInfoTitle: '規格',
      additionalInfoDescription1: p.specification || p.flower_materials || '',
    }));

    const csv = Papa.unparse(exportData);
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'royalspl-products.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function removeImage(index: number) {
    setForm((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }));
  }

  const filteredProducts = products.filter(product => {
    const matchesCategory = filterCategory === 'all' || product.category_id === filterCategory;
    const matchesKeyword = searchKeyword === '' || 
      product.name.toLowerCase().includes(searchKeyword.toLowerCase()) || 
      (product.sku_code && product.sku_code.toLowerCase().includes(searchKeyword.toLowerCase()));
    
    return matchesCategory && matchesKeyword;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">產品管理</h1>
          <p className="text-muted-foreground">管理您的花藝產品</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={handleCsvDownload}>
            <Download className="mr-2 h-4 w-4" />
            匯出 CSV
          </Button>
          <div className="relative">
            <Label className="cursor-pointer" htmlFor="csv-upload">
              <Button variant="outline" disabled={uploading} asChild>
                <span>
                  <Upload className="mr-2 h-4 w-4" />
                  {uploading ? '匯入中...' : '匯入 CSV'}
                </span>
              </Button>
            </Label>
            <Input 
              id="csv-upload"
              type="file" 
              accept=".csv" 
              className="hidden" 
              onChange={handleCsvUpload}
              disabled={uploading}
            />
          </div>
          <Button onClick={openCreate}>
            <Plus className="mr-2 h-4 w-4" />
            新增產品
          </Button>
        </div>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row">
        <div className="w-full sm:max-w-xs">
          <Input 
            placeholder="搜尋產品名稱或 SKU..." 
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
          />
        </div>
        <div className="w-full sm:max-w-[200px]">
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger>
              <SelectValue placeholder="所有分類" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">所有分類</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category.id} value={category.id}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-12 bg-muted animate-pulse rounded" />
          ))}
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-card overflow-hidden">
          <div className="w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">SKU</TableHead>
                  <TableHead className="whitespace-nowrap">產品</TableHead>
                  <TableHead className="whitespace-nowrap">分類</TableHead>
                  <TableHead className="whitespace-nowrap">價格 (HK$)</TableHead>
                  <TableHead className="whitespace-nowrap">精選</TableHead>
                  <TableHead className="whitespace-nowrap">啟用</TableHead>
                  <TableHead className="whitespace-nowrap">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    <TableRow key={product.id}>
                      <TableCell className="whitespace-nowrap text-muted-foreground">
                        {product.sku_code ? product.sku_code.substring(0, 5) : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center gap-3">
                          {product.images?.[0] && (
                            <img
                              src={product.images[0]}
                              alt={product.name}
                              className="h-10 w-10 rounded object-cover"
                            />
                          )}
                          <span className="font-medium text-foreground">{product.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">
                        {product.category?.name || '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-foreground">
                        HK${Number(product.price).toFixed(2)}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        {product.featured ? '是' : '否'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        {product.is_active ? '是' : '否'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="icon" onClick={() => openEdit(product)}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">編輯</span>
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => setDeletingId(product.id)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                            <span className="sr-only">刪除</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      暫無產品。
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? '編輯產品' : '新增產品'}</DialogTitle>
            <DialogDescription>
              {editingId ? '更新產品資訊。' : '建立新的產品。'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="name">名稱</Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="產品名稱"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="slug">網址代碼</Label>
                <Input
                  id="slug"
                  value={form.slug}
                  onChange={(e) => setForm({ ...form, slug: e.target.value })}
                  placeholder="product-slug"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="category">分類</Label>
                <Select
                  value={form.category_id}
                  onValueChange={(value) => setForm({ ...form, category_id: value })}
                >
                  <SelectTrigger id="category">
                    <SelectValue placeholder="選擇分類" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">無</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">售價 (HK$)</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                  placeholder="0.00"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="original_price">原價 (HK$)</Label>
                <Input
                  id="original_price"
                  type="number"
                  step="0.01"
                  value={form.original_price}
                  onChange={(e) => setForm({ ...form, original_price: e.target.value })}
                  placeholder="0.00"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="style_tags">風格標籤 (逗號分隔)</Label>
                <Input
                  id="style_tags"
                  value={form.style_tags}
                  onChange={(e) => setForm({ ...form, style_tags: e.target.value })}
                  placeholder="浪漫, 雅緻"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="scent_notes">香氣筆記 (逗號分隔)</Label>
                <Input
                  id="scent_notes"
                  value={form.scent_notes}
                  onChange={(e) => setForm({ ...form, scent_notes: e.target.value })}
                  placeholder="牡丹馥郁, 蜂蜜, 白麝香"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="flower_materials">花材</Label>
                <Input
                  id="flower_materials"
                  value={form.flower_materials}
                  onChange={(e) => setForm({ ...form, flower_materials: e.target.value })}
                  placeholder="粉紅牡丹、黃色文心蘭"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="origin">產地</Label>
                <Input
                  id="origin"
                  value={form.origin}
                  onChange={(e) => setForm({ ...form, origin: e.target.value })}
                  placeholder="荷蘭・阿姆斯特丹"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="specification">規格</Label>
              <Input
                id="specification"
                value={form.specification}
                onChange={(e) => setForm({ ...form, specification: e.target.value })}
                placeholder="約 12 支牡丹"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">描述</Label>
              <Textarea
                id="description"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="產品描述"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="image">圖片</Label>
              <Input
                id="image"
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                disabled={uploading}
              />
              <p className="text-xs text-muted-foreground">最大 1MB，支援 JPG、PNG、WEBP。</p>
            </div>

            {form.images.length > 0 && (
              <div className="flex flex-wrap gap-3">
                {form.images.map((image, index) => (
                  <div key={index} className="relative h-20 w-20">
                    <img src={image} alt="" className="h-full w-full rounded object-cover" />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-destructive-foreground"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex flex-col gap-3 md:flex-row">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="featured"
                  checked={form.featured}
                  onCheckedChange={(checked) => setForm({ ...form, featured: checked === true })}
                />
                <Label htmlFor="featured" className="font-normal">設為精選</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="active"
                  checked={form.is_active}
                  onCheckedChange={(checked) => setForm({ ...form, is_active: checked === true })}
                />
                <Label htmlFor="active" className="font-normal">啟用</Label>
              </div>
            </div>

            <DialogFooter>
              <Button type="submit">{editingId ? '更新產品' : '建立產品'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deletingId} onOpenChange={(open) => !open && setDeletingId(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader>
            <DialogTitle>刪除產品</DialogTitle>
            <DialogDescription>確定要刪除此產品嗎？</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeletingId(null)}>
              取消
            </Button>
            <Button variant="destructive" onClick={() => deletingId && handleDelete(deletingId)}>
              刪除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
