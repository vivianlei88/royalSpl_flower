import { useEffect, useState } from 'react';
import { Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { getInquiries, updateInquiryStatus } from '@/services/api';
import type { Inquiry } from '@/types/types';
import { toast } from 'sonner';

const statusOptions = [
  { value: 'pending', label: '待處理' },
  { value: 'processing', label: '處理中' },
  { value: 'completed', label: '已完成' },
];

export default function AdminOrders() {
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const data = await getInquiries();
    setInquiries(data);
    setLoading(false);
  }

  async function handleStatusChange(id: string, status: string) {
    const success = await updateInquiryStatus(id, status);
    if (success) {
      toast.success('狀態已更新。');
      setInquiries((prev) =>
        prev.map((inquiry) => (inquiry.id === id ? { ...inquiry, status } : inquiry))
      );
    } else {
      toast.error('狀態更新失敗。');
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-foreground">訂單與詢價</h1>
        <p className="text-muted-foreground">管理客戶詢價與訂單</p>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-12 bg-muted animate-pulse rounded" />
          ))}
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-card overflow-hidden">
          <div className="w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">客戶</TableHead>
                  <TableHead className="whitespace-nowrap">產品</TableHead>
                  <TableHead className="whitespace-nowrap">總計 (HK$)</TableHead>
                  <TableHead className="whitespace-nowrap">電話</TableHead>
                  <TableHead className="whitespace-nowrap">日期</TableHead>
                  <TableHead className="whitespace-nowrap">狀態</TableHead>
                  <TableHead className="whitespace-nowrap">留言</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {inquiries.length > 0 ? (
                  inquiries.map((inquiry) => (
                    <TableRow key={inquiry.id}>
                      <TableCell className="whitespace-nowrap font-medium text-foreground">
                        {inquiry.name}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">
                        {inquiry.items ? (
                          <div className="space-y-1 max-w-[200px]">
                            {inquiry.items.map((item) => (
                              <div key={item.id} className="truncate" title={item.product?.name}>
                                {item.product?.name} x{item.quantity}
                              </div>
                            ))}
                          </div>
                        ) : '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-foreground font-medium">
                        HK${Number(inquiry.total_amount || 0).toFixed(2)}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">
                        {inquiry.phone}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">
                        {new Date(inquiry.created_at).toLocaleDateString('zh-HK')}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Select
                          value={inquiry.status}
                          onValueChange={(value) => handleStatusChange(inquiry.id, value)}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {statusOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="whitespace-nowrap max-w-[200px] truncate text-muted-foreground">
                        {inquiry.message || '—'}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      暫無詢價。
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </div>
  );
}
