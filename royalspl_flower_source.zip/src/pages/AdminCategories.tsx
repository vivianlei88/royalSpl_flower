import { useEffect, useState } from 'react';
import { Pencil, Trash2, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { getCategories, createCategory, updateCategory, deleteCategory, uploadProductImage } from '@/services/api';
import type { Category } from '@/types/types';
import { toast } from 'sonner';

export default function AdminCategories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', slug: '', image_url: '', description: '' });
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const data = await getCategories();
    setCategories(data);
    setLoading(false);
  }

  function resetForm() {
    setForm({ name: '', slug: '', image_url: '', description: '' });
    setEditingId(null);
  }

  function openEdit(category: Category) {
    setEditingId(category.id);
    setForm({ name: category.name, slug: category.slug, image_url: category.image_url || '', description: category.description || '' });
    setDialogOpen(true);
  }

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 1024) {
      toast.error('圖片必須小於 1MB。');
      return;
    }

    setUploading(true);
    const filename = `${Date.now()}-${file.name}`;
    const url = await uploadProductImage(file, filename);
    setUploading(false);

    if (url) {
      setForm((prev) => ({ ...prev, image_url: url }));
    } else {
      toast.error('圖片上傳失敗。');
    }
  }

  function openCreate() {
    resetForm();
    setDialogOpen(true);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();

    if (!form.name.trim() || !form.slug.trim()) {
      toast.error('請填寫名稱和網址代碼。');
      return;
    }

    let result;
    if (editingId) {
      result = await updateCategory(editingId, form.name.trim(), form.slug.trim(), form.image_url.trim() || undefined, form.description.trim() || undefined);
    } else {
      result = await createCategory(form.name.trim(), form.slug.trim(), form.image_url.trim() || undefined, form.description.trim() || undefined);
    }

    if (result) {
      toast.success(editingId ? '類別已更新。' : '類別已建立。');
      setDialogOpen(false);
      resetForm();
      loadData();
    } else {
      toast.error('類別儲存失敗。');
    }
  }

  async function handleDelete(id: string) {
    const success = await deleteCategory(id);
    if (success) {
      toast.success('類別已刪除。');
      setDeletingId(null);
      loadData();
    } else {
      toast.error('刪除類別失敗，可能存在關聯的產品。');
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">類別管理</h1>
          <p className="text-muted-foreground">管理商店產品類別</p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="mr-2 h-4 w-4" />
          新增類別
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-12 bg-muted animate-pulse rounded" />
          ))}
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-card overflow-hidden">
          <div className="w-full overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">圖片</TableHead>
                  <TableHead className="whitespace-nowrap">名稱</TableHead>
                  <TableHead className="whitespace-nowrap">網址代碼 (Slug)</TableHead>
                  <TableHead className="whitespace-nowrap">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.length > 0 ? (
                  categories.map((category) => (
                    <TableRow key={category.id}>
                      <TableCell className="whitespace-nowrap">
                        {category.image_url ? (
                          <img src={category.image_url} alt={category.name} className="h-10 w-10 object-cover rounded" />
                        ) : (
                          <div className="h-10 w-10 bg-muted rounded flex items-center justify-center text-xs text-muted-foreground">無</div>
                        )}
                      </TableCell>
                      <TableCell className="whitespace-nowrap font-medium text-foreground">
                        {category.name}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">
                        {category.slug}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="icon" onClick={() => openEdit(category)}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">編輯</span>
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => setDeletingId(category.id)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                            <span className="sr-only">刪除</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-muted-foreground py-8">
                      暫無類別。
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader>
            <DialogTitle>{editingId ? '編輯類別' : '新增類別'}</DialogTitle>
            <DialogDescription>
              {editingId ? '更新類別資訊。' : '建立新的產品類別。'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">名稱</Label>
              <Input
                id="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="例如：乾燥花"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slug">網址代碼 (Slug)</Label>
              <Input
                id="slug"
                value={form.slug}
                onChange={(e) => setForm({ ...form, slug: e.target.value })}
                placeholder="例如：dried-flowers"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">介紹</Label>
              <Input
                id="description"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="類別介紹..."
              />
            </div>
            <div className="space-y-2">
              <Label>類別圖片</Label>
              <div className="flex items-center gap-4">
                {form.image_url && (
                  <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-md border border-border">
                    <img src={form.image_url} alt="" className="h-full w-full object-cover" />
                  </div>
                )}
                <div className="relative flex-1">
                  <Input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="absolute inset-0 h-full w-full opacity-0 cursor-pointer"
                    onChange={handleImageUpload}
                    disabled={uploading}
                  />
                  <div className="absolute inset-0 z-10 pointer-events-none border border-border rounded flex items-center justify-center bg-background/50">
                    <span className="text-sm font-medium">{uploading ? '上傳中...' : form.image_url ? '更換圖片' : '上傳圖片'}</span>
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="submit">{editingId ? '更新' : '建立'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deletingId} onOpenChange={(open) => !open && setDeletingId(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader>
            <DialogTitle>刪除類別</DialogTitle>
            <DialogDescription>確定要刪除此類別嗎？如果有產品屬於此類別，刪除可能會失敗。</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeletingId(null)}>
              取消
            </Button>
            <Button variant="destructive" onClick={() => deletingId && handleDelete(deletingId)}>
              刪除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}