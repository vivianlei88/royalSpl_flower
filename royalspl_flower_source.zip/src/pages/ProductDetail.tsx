import { useEffect, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ShoppingCart, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { getProductBySlug, getProducts } from '@/services/api';
import type { Product } from '@/types/types';
import PageMeta from '@/components/common/PageMeta';
import { useCart } from '@/contexts/CartContext';

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();
  const navigate = useNavigate();

  function handleBuyNow() {
    if (product) {
      addToCart(product, 1);
      navigate('/cart');
    }
  }

  useEffect(() => {
    async function loadData() {
      if (!slug) return;
      const [productData, productsData] = await Promise.all([
        getProductBySlug(slug),
        getProducts(),
      ]);
      setProduct(productData);
      setRelatedProducts(productsData.filter((p) => p.id !== productData?.id).slice(0, 3));
      setLoading(false);
    }
    loadData();
  }, [slug]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 md:px-8">
        <div className="h-96 animate-pulse rounded-lg bg-muted" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-20 text-center md:px-8">
        <h1 className="text-2xl font-semibold text-foreground">找不到產品</h1>
        <p className="mt-2 text-muted-foreground">此產品不存在或已下架。</p>
        <Button className="mt-6" asChild>
          <Link to="/products">返回產品</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 md:py-20 md:px-8">
      <PageMeta
        title={`${product.name} | Royalspl Flower`}
        description="來自 Royalspl Flower 的優雅花藝。"
      />

      <Button variant="ghost" size="sm" asChild className="mb-6">
        <Link to="/products">
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回產品
        </Link>
      </Button>

      <div className="grid gap-10 lg:grid-cols-2">
        <div className="space-y-4">
          <div className="aspect-[4/3] overflow-hidden rounded-lg bg-muted">
            <img
              src={product.images?.[0]}
              alt={product.name}
              className="h-full w-full object-cover"
            />
          </div>
          {product.images && product.images.length > 1 && (
            <div className="grid grid-cols-4 gap-3">
              {product.images.map((image, index) => (
                <div key={index} className="aspect-square overflow-hidden rounded-md bg-muted">
                  <img src={image} alt="" className="h-full w-full object-cover" />
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div>
            <p className="text-sm text-muted-foreground">{product.category?.name}</p>
              <h1 className="mt-2 text-3xl font-semibold text-foreground md:text-4xl">{product.name}</h1>
              {product.english_name && (
                <p className="mt-1 text-lg text-muted-foreground uppercase tracking-wider">{product.english_name}</p>
              )}
              <div className="mt-4 flex items-center gap-4">
                <p className="text-2xl font-medium text-primary">HK${Number(product.price).toFixed(2)}</p>
                {product.original_price && (
                  <p className="text-lg text-muted-foreground line-through">HK${Number(product.original_price).toFixed(2)}</p>
                )}
              </div>
            </div>

            <div className="border-t border-border pt-6">
              <p className="leading-relaxed text-muted-foreground whitespace-pre-wrap">
                {product.description || '暫無描述。'}
              </p>
            </div>

            {/* Tags section */}
            {product.style_tags && product.style_tags.length > 0 && (
              <div className="border-t border-border pt-6">
                <div className="flex justify-between relative">
                  {product.style_tags.map((tag, i) => (
                    <span key={i} className="text-sm tracking-widest text-muted-foreground">
                      {tag}
                    </span>
                  ))}
                  <div className="absolute top-1/2 left-0 right-0 h-px bg-border -z-10" />
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-2 w-2 rounded-full bg-[#B29E93]" />
                </div>
              </div>
            )}

            {/* Scent notes section */}
            {product.scent_notes && product.scent_notes.length > 0 && (
              <div className="border-t border-border pt-6">
                <h3 className="text-sm tracking-[0.2em] text-muted-foreground mb-4">香氣筆記 · SCENT NOTES</h3>
                <div className="flex gap-2 flex-wrap">
                  {product.scent_notes.map((note, i) => (
                    <span key={i} className="px-4 py-2 border border-border text-sm">
                      {note}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Specifications section */}
            <div className="border-t border-border pt-6 space-y-4">
              {product.flower_materials && (
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground w-20 shrink-0">花材</span>
                  <span className="text-right">{product.flower_materials}</span>
                </div>
              )}
              {product.origin && (
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground w-20 shrink-0">產地</span>
                  <span className="text-right">{product.origin}</span>
                </div>
              )}
              {product.specification && (
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground w-20 shrink-0">規格</span>
                  <span className="text-right whitespace-pre-wrap">{product.specification}</span>
                </div>
              )}
            </div>

            <div className="border-t border-border pt-6 flex gap-4">
              <Button size="lg" variant="outline" className="flex-1" onClick={() => addToCart(product, 1)}>
                <ShoppingCart className="mr-2 h-5 w-5" />
                加入購物車
              </Button>
              <Button size="lg" className="flex-1" onClick={handleBuyNow}>
                <CreditCard className="mr-2 h-5 w-5" />
                立即購買
              </Button>
            </div>
          </div>
        </div>

      {relatedProducts.length > 0 && (
        <section className="mt-20">
          <h2 className="text-2xl font-semibold text-foreground mb-8">您可能也喜歡</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {relatedProducts.map((item) => (
              <Link key={item.id} to={`/product/${item.slug}`}>
                <Card className="h-full overflow-hidden border border-border bg-card transition-colors hover:border-primary/50">
                  <div className="aspect-[4/3] overflow-hidden bg-muted">
                    <img
                      src={item.images?.[0]}
                      alt={item.name}
                      className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-5">
                    <h3 className="text-base font-semibold text-foreground">{item.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{item.category?.name}</p>
                    <p className="mt-2 text-base font-medium text-primary">HK${Number(item.price).toFixed(2)}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
