import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { getSiteContent, updateSiteContent } from '@/services/api';
import { toast } from 'sonner';

const defaultFields: Record<string, string> = {
  hero_title: 'Royalspl Flower',
  hero_subtitle: '為每一個時刻精心打造的優雅花藝',
  hero_image: '',
  about_title: '關於 Royalspl Flower',
  about_text: '我們是一家本地花藝工作室，致力於創作細膩而優雅的花藝作品。',
  footer_text: '為每一個時刻精心打造的優雅花藝。',
  contact_address: '花園區布魯姆街 123 號',
  contact_hours: '週一至週六：09:00 - 19:00',
  contact_phone: '+852 1234 5678',
  contact_email: 'hello@royalsplflower.com',
};

export default function AdminContent() {
  const [content, setContent] = useState<Record<string, string>>(defaultFields);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    async function loadData() {
      const data = await getSiteContent();
      setContent({ ...defaultFields, ...data });
      setLoading(false);
    }
    loadData();
  }, []);

  async function handleSave() {
    setSaving(true);
    const results = await Promise.all(
      Object.entries(content).map(([key, value]) => updateSiteContent(key, value))
    );
    setSaving(false);

    if (results.every(Boolean)) {
      toast.success('網站內容已更新。');
    } else {
      toast.error('部分內容儲存失敗。');
    }
  }

  function updateField(key: string, value: string) {
    setContent((prev) => ({ ...prev, [key]: value }));
  }

  const fields = [
    { key: 'hero_title', label: '首頁主標題', type: 'text' },
    { key: 'hero_subtitle', label: '首頁副標題', type: 'text' },
    { key: 'hero_image', label: '首頁主圖網址', type: 'text' },
    { key: 'about_title', label: '關於我們標題', type: 'text' },
    { key: 'about_text', label: '關於我們內容', type: 'textarea' },
    { key: 'footer_text', label: '頁尾文字', type: 'textarea' },
  ];

  const contactFields = [
    { key: 'contact_address', label: '地址', type: 'text' },
    { key: 'contact_hours', label: '營業時間', type: 'text' },
    { key: 'contact_phone', label: '電話', type: 'text' },
    { key: 'contact_email', label: '電子郵件', type: 'text' },
  ];

  if (loading) {
    return <div className="h-96 bg-muted animate-pulse rounded-lg" />;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-foreground">網站內容</h1>
        <p className="text-muted-foreground">更新網站內容與聯絡資訊</p>
      </div>

      <div className="space-y-6">
        <div className="rounded-lg border border-border bg-card p-6 space-y-4">
          <h2 className="text-lg font-semibold text-foreground">首頁與關於</h2>
          {fields.map((field) => (
            <div key={field.key} className="space-y-2">
              <Label htmlFor={field.key}>{field.label}</Label>
              {field.type === 'textarea' ? (
                <Textarea
                  id={field.key}
                  value={content[field.key] || ''}
                  onChange={(e) => updateField(field.key, e.target.value)}
                  rows={4}
                />
              ) : (
                <Input
                  id={field.key}
                  value={content[field.key] || ''}
                  onChange={(e) => updateField(field.key, e.target.value)}
                />
              )}
            </div>
          ))}
        </div>

        <div className="rounded-lg border border-border bg-card p-6 space-y-4">
          <h2 className="text-lg font-semibold text-foreground">聯絡資訊</h2>
          {contactFields.map((field) => (
            <div key={field.key} className="space-y-2">
              <Label htmlFor={field.key}>{field.label}</Label>
              <Input
                id={field.key}
                value={content[field.key] || ''}
                onChange={(e) => updateField(field.key, e.target.value)}
              />
            </div>
          ))}
        </div>

        <Button onClick={handleSave} disabled={saving} className="w-full md:w-auto">
          {saving ? '儲存中...' : '儲存'}
        </Button>
      </div>
    </div>
  );
}
